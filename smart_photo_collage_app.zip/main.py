
import os
from utils.remove_bg import remove_background
from utils.face_detection import detect_faces
from utils.image_tools import resize_image_uniformly, enhance_image
from collage_builder import create_collage
from PIL import Image

# Configuration
INPUT_FOLDER = "samples"
OUTPUT_FOLDER = "assets"
MAIN_IMAGE_NAME = "main.jpg"  # Replace with the name of your main image

def main():
    print("Starting Smart Collage App...")
    
    os.makedirs(OUTPUT_FOLDER, exist_ok=True)
    
    images = []
    main_img_path = os.path.join(INPUT_FOLDER, MAIN_IMAGE_NAME)
    all_files = [f for f in os.listdir(INPUT_FOLDER) if f.lower().endswith(('png', 'jpg', 'jpeg')) and f != MAIN_IMAGE_NAME]
    
    # Process central image
    print("Removing background from main image...")
    central_img = remove_background(main_img_path)
    
    # Process background images
    for filename in all_files:
        img_path = os.path.join(INPUT_FOLDER, filename)
        print(f"Processing {filename}...")
        img = Image.open(img_path).convert("RGB")
        
        # Detect faces to avoid cropping
        faces = detect_faces(img)
        
        # Resize keeping aspect ratio and avoid face cropping
        resized_img = resize_image_uniformly(img, faces)
        
        # Enhance image if needed
        enhanced = enhance_image(resized_img)
        
        images.append(enhanced)
    
    # Compose final collage
    print("Creating collage...")
    collage = create_collage(central_img, images)
    
    # Save output
    collage.save(os.path.join(OUTPUT_FOLDER, "final_collage.jpg"))
    print("Collage saved to assets/final_collage.jpg")

if __name__ == "__main__":
    main()
