
from PIL import Image

def create_collage(central_img, bg_images, canvas_size=(1200, 800)):
    collage = Image.new("RGB", canvas_size, color=(255, 255, 255))

    # Place background images in grid
    rows = 2
    cols = len(bg_images) // rows + (len(bg_images) % rows > 0)
    w, h = 300, 500
    margin = 20
    for i, img in enumerate(bg_images):
        row = i // cols
        col = i % cols
        x = margin + col * (w + margin)
        y = margin + row * (h + margin)
        collage.paste(img.resize((w, h)), (x, y))

    # Paste central image in the middle (with transparency)
    c_w, c_h = central_img.size
    center_x = (canvas_size[0] - c_w) // 2
    center_y = (canvas_size[1] - c_h) // 2
    collage.paste(central_img, (center_x, center_y), central_img)

    return collage
