
from rembg import remove
from PIL import Image
import io

def remove_background(image_path):
    with open(image_path, 'rb') as f:
        input_data = f.read()
        result = remove(input_data)
        return Image.open(io.BytesIO(result)).convert("RGBA")
