
import streamlit as st
from PIL import Image
import os
from utils.remove_bg import remove_background
from utils.face_detection import detect_faces
from utils.image_tools import resize_image_uniformly, enhance_image
from collage_builder import create_collage

st.set_page_config(page_title="Smart Collage Generator", layout="wide")
st.title("Smart Collage Generator")

st.markdown("### 1. Upload Images")
uploaded_files = st.file_uploader("Upload background images", type=["png", "jpg", "jpeg"], accept_multiple_files=True)
main_image_file = st.file_uploader("Upload main image (center)", type=["png", "jpg", "jpeg"])

if uploaded_files and main_image_file:
    st.markdown("### 2. Preview")
    cols = st.columns(len(uploaded_files))
    for i, file in enumerate(uploaded_files):
        img = Image.open(file)
        cols[i].image(img, use_column_width=True, caption=f"Image {i+1}")

    central_img = Image.open(main_image_file)
    st.image(central_img, caption="Central Image", use_column_width=False)

    if st.button("Generate Collage"):
        st.markdown("### 3. Processing...")

        # Process central image
        central_img_nobg = remove_background(main_image_file)

        bg_images = []
        for file in uploaded_files:
            img = Image.open(file).convert("RGB")
            faces = detect_faces(img)
            resized = resize_image_uniformly(img, faces)
            enhanced = enhance_image(resized)
            bg_images.append(enhanced)

        collage = create_collage(central_img_nobg, bg_images)
        st.image(collage, caption="Final Collage", use_column_width=True)

        # Save result
        output_path = "assets/final_collage_web.jpg"
        os.makedirs("assets", exist_ok=True)
        collage.save(output_path)
        with open(output_path, "rb") as file:
            st.download_button("Download Collage", file, file_name="final_collage.jpg")
else:
    st.warning("Please upload both background images and a central image.")
