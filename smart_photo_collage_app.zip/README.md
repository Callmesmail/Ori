# Smart Photo Collage Generator

A Python application that generates professional photo collages with a centered main image and smart background arrangement.

## Features
- Auto or manual selection of a central image.
- Background removal using `rembg`.
- Face/person detection to avoid cropping people.
- Background image outpainting when needed.
- High-quality grid layout with vertical photos.
- Output in high resolution.

## How to Use
1. Place your images in the `samples/` folder.
2. Run `main.py`.
3. The final collage will be saved in the `assets/` folder.

## Requirements
Install dependencies with:
```
pip install -r requirements.txt
```
